manifest = {
    client: [
        {
            id: 17,
            name: "values",
            data: {
                valChar: "char",
                valByte: "byte",
                valUByte: "ubyte",
                valInt16: "int16",
                valUInt16: "uint16",
                valInt32: "int32",
                valUInt32: "uint32",
                valObject: {
                    objChar: "char",
                    objInt32: "int32",
                    objFloat: "double",
                    objDate: "date"
                },
                valFloat: "float",
                valDouble: "double",
                valCurrency: "currency",
                valString: "string",
                valDateTime: "datetime",
                valDate: "date",
                valTime: "time"
            }
        },
        {
            id: 29,
            name: "arrays",
            data: {
                arrChar: [{
                    valChar: "char"
                }],
                arrInt32: [{
                    valInt32: "int32"
                }],
                arrFloat: [{
                    valFloat: "double"
                }],
                arrDate: [{
                    valDate: "date"
                }],
                arrMixed: [{
                    valChar: "char",
                    valInt32: "int32",
                    valFloat: "double",
                    valDate: "date"
                }]
            }
        }
    ],
    server: [
        {
            "id": 2,
            "name": "stock",
            "data": {
                "stock": {
                    "id": "int32",
                    "symbol": "string",
                    "name": "string",
                    "notes": "string",
                    "quarter_view": "bool",
                    "last_closed": "float",
                    "last_closed_percent": "float"
                },
                "report": {
                    "id": "int32",
                    "year": "int16",
                    "quarter": "byte",
                    "date": "date",
                    "premarket_afterhours": "string",
                    "earnings_prediction": "float",
                    "earnings": "float",
                    "close_prediction": "float",
                    "close": "float"
                }
            }
        },
        {
            id: 48,
            name: "values",
            data: {
                valChar: "char",
                valByte: "byte",
                valUByte: "ubyte",
                valInt16: "int16",
                valUInt16: "uint16",
                valInt32: "int32",
                valUInt32: "uint32",
                valObject: {
                    objChar: "char",
                    objInt32: "int32",
                    objFloat: "double",
                    objDate: "date"
                },
                valFloat: "float",
                valDouble: "double",
                valCurrency: "currency",
                valString: "string",
                valDateTime: "datetime",
                valDate: "date",
                valTime: "time"
            }
        },
        {
            id: 211,
            name: "arrays",
            data: {
                arrChar: [{
                    valChar: "char"
                }],
                arrInt32: [{
                    valInt32: "int32"
                }],
                arrFloat: [{
                    valFloat: "double"
                }],
                arrDate: [{
                    valDate: "date"
                }],
                arrMixed: [{
                    valChar: "char",
                    valInt32: "int32",
                    valFloat: "double",
                    valDate: "date"
                }]
            }
        }
    ]
};