  DateTime = (function() {
    DateTime.prototype.setFullYear = function(val) {
      return this.dt.setFullYear(val);
    };

    DateTime.prototype.setMonth = function(val) {
      return this.dt.setMonth(val);
    };

    DateTime.prototype.setDate = function(val) {
      return this.dt.setDate(val);
    };

    DateTime.prototype.setHours = function(val) {
      return this.dt.setHours(val);
    };

    DateTime.prototype.setMinutes = function(val) {
      return this.dt.setMinutes(val);
    };

    DateTime.prototype.setSeconds = function(val) {
      return this.dt.setSeconds(val);
    };

    DateTime.prototype.setMilliseconds = function(val) {
      return this.dt.setMilliseconds(val);
    };

    DateTime.prototype.setTime = function(val) {
      return this.dt.setTime(val);
    };

    DateTime.prototype.getFullYear = function() {
      return this.dt.getFullYear();
    };

    DateTime.prototype.getMonth = function() {
      return this.dt.getMonth();
    };

    DateTime.prototype.getDate = function() {
      return this.dt.getDate();
    };

    DateTime.prototype.getDay = function() {
      return this.dt.getDay();
    };

    DateTime.prototype.getHours = function() {
      return this.dt.getHours();
    };

    DateTime.prototype.getMinutes = function() {
      return this.dt.getMinutes();
    };

    DateTime.prototype.getSeconds = function() {
      return this.dt.getSeconds();
    };

    DateTime.prototype.getMilliseconds = function() {
      return this.dt.getMilliseconds();
    };

    DateTime.prototype.getTime = function() {
      return this.dt.getTime();
    };

    DateTime.prototype.setUTCFullYear = function(val) {
      return this.dt.setUTCFullYear(val);
    };

    DateTime.prototype.setUTCMonth = function(val) {
      return this.dt.setUTCMonth(val);
    };

    DateTime.prototype.setUTCDate = function(val) {
      return this.dt.setUTCDate(val);
    };

    DateTime.prototype.setUTCHours = function(val) {
      return this.dt.setUTCHours(val);
    };

    DateTime.prototype.setUTCMinutes = function(val) {
      return this.dt.setUTCMinutes(val);
    };

    DateTime.prototype.setUTCSeconds = function(val) {
      return this.dt.setUTCSeconds(val);
    };

    DateTime.prototype.setUTCMilliseconds = function(val) {
      return this.dt.setUTCMilliseconds(val);
    };

    DateTime.prototype.getUTCFullYear = function() {
      return this.dt.getUTCFullYear();
    };

    DateTime.prototype.getUTCMonth = function() {
      return this.dt.getUTCMonth();
    };

    DateTime.prototype.getUTCDate = function() {
      return this.dt.getUTCDate();
    };

    DateTime.prototype.getUTCDay = function() {
      return this.dt.getUTCDay();
    };

    DateTime.prototype.getUTCHours = function() {
      return this.dt.getUTCHours();
    };

    DateTime.prototype.getUTCMinutes = function() {
      return this.dt.getUTCMinutes();
    };

    DateTime.prototype.getUTCSeconds = function() {
      return this.dt.getUTCSeconds();
    };

    DateTime.prototype.getUTCMilliseconds = function() {
      return this.dt.getUTCMilliseconds();
    };

    DateTime.prototype.date = function() {
      return this.dt;
    };

    DateTime.prototype.clone = function() {
      return new DateTime(this.dt);
    };

    DateTime.prototype.add = function(delta) {
      this.dt.setTime(this.dt.getTime() + delta);
      return this;
    };

    DateTime.prototype.subtract = function(delta) {
      return this.add(-delta);
    };

    DateTime.prototype.timestamp = function(ms) {
      if (ms == null) {
        ms = false;
      }
      return this.format("Y-m-d H:i:s" + (ms ? '.u' : ''), false);
    };

    DateTime.prototype.timestampUTC = function(ms) {
      if (ms == null) {
        ms = false;
      }
      return this.format("Y-m-d H:i:s" + (ms ? '.u' : ''), true);
    };

    DateTime.prototype.format = function(pattern, utc) {
      var $this, c, dt, fmt, i, j, len, map, result, skip;
      if (pattern == null) {
        pattern = 'Y-m-d H:i:s';
      }
      if (utc == null) {
        utc = false;
      }
      $this = this;
      dt = this.dt;
      fmt = function(val, digits) {
        var arr, i, j, ref, result;
        if (digits == null) {
          digits = 2;
        }
        val += '';
        arr = val.split('').reverse();
        if (digits > arr.length) {
          result = '';
          for (i = j = ref = digits - 1; j >= 0; i = j += -1) {
            result += i < arr.length ? arr[i] : '0';
          }
          return result;
        } else {
          return val;
        }
      };
      map = function(char) {
        var d, dayN, dst, firstThu, fullDays, fullMonths, getDate, getDay, getFullYear, getHours, getMilliseconds, getMinutes, getMonth, getSeconds, i, j, o, shortDays, shortMonths, tgt, y;
        fullMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        fullDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        getFullYear = function(utc) {
          if (!utc) {
            return dt.getFullYear();
          } else {
            return dt.getUTCFullYear();
          }
        };
        getMonth = function(utc) {
          if (!utc) {
            return dt.getMonth();
          } else {
            return dt.getUTCMonth();
          }
        };
        getDate = function(utc) {
          if (!utc) {
            return dt.getDate();
          } else {
            return dt.getUTCDate();
          }
        };
        getDay = function(utc) {
          if (!utc) {
            return dt.getDay();
          } else {
            return dt.getUTCDay();
          }
        };
        getHours = function(utc) {
          if (!utc) {
            return dt.getHours();
          } else {
            return dt.getUTCHours();
          }
        };
        getMinutes = function(utc) {
          if (!utc) {
            return dt.getMinutes();
          } else {
            return dt.getUTCMinutes();
          }
        };
        getSeconds = function(utc) {
          if (!utc) {
            return dt.getSeconds();
          } else {
            return dt.getUTCSeconds();
          }
        };
        getMilliseconds = function(utc) {
          if (!utc) {
            return dt.getMilliseconds();
          } else {
            return dt.getUTCMilliseconds();
          }
        };
        switch (char) {
          case 'Y':
            return fmt(getFullYear(utc), 4);
          case 'y':
            return fmt(getFullYear(utc) % 100);
          case 'L':
            y = getFullYear(utc);
            if (y % 400 === 0 || (y % 100 !== 0 && y % 4 === 0)) {
              return 1;
            } else {
              return 0;
            }
            break;
          case 'o':
            d = new Date(dt.getTime());
            d.setDate(d.getDate() - ((dt.getDay() + 6) % 7) + 3);
            return d.getFullYear();
          case 'm':
            return fmt(getMonth(utc) + 1);
          case 'n':
            return getMonth(utc) + 1;
          case 'F':
            return fullMonths[getMonth(utc)];
          case 'M':
            return shortMonths[getMonth(utc)];
          case 't':
            return new Date(getFullYear(utc), (getMonth(utc) + 1) % 12, 0).getDate();
          case 'W':
            tgt = new Date(dt.getTime());
            dayN = (dt.getDay() + 6) % 7;
            tgt.setDate(tgt.getDate() - dayN + 3);
            firstThu = tgt.getTime();
            tgt.setMonth(0, 1);
            if (tgt.getDay() !== 4) {
              tgt.setMonth(0, 1 + ((4 - tgt.getDay()) + 7) % 7);
            }
            return 1 + Math.ceil((firstThu - tgt) / 604800000);
          case 'd':
            return fmt(getDate(utc));
          case 'j':
            return getDate(utc);
          case 'z':
            d = new Date(getFullYear(utc), 0, 1);
            return Math.floor((dt - d + (utc ? dt.getTimezoneOffset() * 60000 : 0)) / 86400000);
          case 'w':
            return getDay(utc);
          case 'N':
            return getDay(utc) || 7;
          case 'l':
            return fullDays[getDay(utc)];
          case 'D':
            return shortDays[getDay(utc)];
          case 'S':
            d = getDate(utc);
            if (d % 10 === 1 && d !== 11) {
              return 'st';
            } else {
              if (d % 10 === 2 && d !== 12) {
                return 'nd';
              } else {
                if (d % 10 === 3 && d !== 13) {
                  return 'rd';
                } else {
                  return 'th';
                }
              }
            }
            break;
          case 'H':
            return fmt(getHours(utc));
          case 'G':
            return getHours(utc);
          case 'h':
            return fmt(getHours(utc) % 12);
          case 'g':
            return getHours(utc) % 12;
          case 'A':
            if (getHours(utc) < 12) {
              return 'AM';
            } else {
              return 'PM';
            }
          case 'a':
            if (getHours(utc) < 12) {
              return 'am';
            } else {
              return 'pm';
            }
          case 'i':
            return fmt(getMinutes(utc));
          case 's':
            return fmt(getSeconds(utc));
          case 'u':
            return fmt(getMilliseconds(utc), 3);
          case 'B':
            return Math.floor((((dt.getUTCHours() + 1) % 24) + dt.getUTCMinutes() / 60 + dt.getUTCSeconds() / 3600) * 1000 / 24);
          case 'I':
            if (utc) {
              return 0;
            }
            for (i = j = 0; j < 12; i = ++j) {
              d = new Date(dt.getFullYear(), i, 1);
              o = d.getTimezoneOffset();
              if (typeof dst === "undefined" || dst === null) {
                dst = o;
              } else if (o !== dst) {
                if (o < dst) {
                  dst = o;
                }
                break;
              }
            }
            return (dt.getTimezoneOffset() === dst) | 0;
          case 'O':
            if (utc) {
              return '+0000';
            }
            o = -dt.getTimezoneOffset();
            return (o < 0 ? '-' : '+') + fmt(Math.floor(Math.abs(o / 60))) + fmt(Math.abs(o % 60));
          case 'P':
            if (utc) {
              return '+00:00';
            }
            o = -dt.getTimezoneOffset();
            return (o < 0 ? '-' : '+') + fmt(Math.floor(Math.abs(o / 60))) + ':' + fmt(Math.abs(o % 60));
          case 'T':
            if (!utc) {
              return dt.toTimeString().replace(/^.+ \(?([^\)]+)\)?$/, '$1');
            } else {
              return 'UTC';
            }
          case 'Z':
            if (!utc) {
              return -dt.getTimezoneOffset() * 60;
            } else {
              return 0;
            }
          case 'c':
            return $this.format('Y-m-d\\TH:i:sP', utc);
          case 'r':
            return $this.format('D, j M Y H:i:s O', utc);
          case 'U':
            return Math.floor(dt.getTime() / 1000);
          default:
            return char;
        }
      };
      pattern = pattern.split('');
      result = '';
      for (i = j = 0, len = pattern.length; j < len; i = ++j) {
        c = pattern[i];
        if (c === '\\') {
          skip = true;
          continue;
        }
        if (!skip) {
          result += map(c);
        } else {
          result += c;
          skip = false;
        }
      }
      return result;
    };

    DateTime.prototype.set = function(value) {
      var d, h, i, m, ms, ref, s, y;
      if (value instanceof Date) {
        this.dt = new Date(value.getTime());
      } else {
        this.dt = new Date;
        if (typeof value === 'string') {
          ref = value.split(/\D/), y = ref[0], m = ref[1], d = ref[2], h = ref[3], i = ref[4], s = ref[5], ms = ref[6];
          if ((y != null) && (m != null) && (d != null)) {
            this.dt.setUTCMilliseconds(ms | 0);
            this.dt.setUTCSeconds(s | 0);
            this.dt.setUTCMinutes(i | 0);
            this.dt.setUTCHours(h | 0);
            this.dt.setUTCFullYear(y);
            this.dt.setUTCMonth(m - 1);
            this.dt.setUTCDate(d);
          }
        }
      }
      return this;
    };

    function DateTime(value) {
      this.set(value);
    }

    return DateTime;

  })();
