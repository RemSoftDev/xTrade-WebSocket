var WS = function () {
    var socket = null;
    var debug = false;
    var reconnect = false;
    var id = 1;
    var handlers = new Array();

    this.debug = function (enabled) {
        debug = enabled;
    }

    this.addHandler = function (handler) {
        handlers.push(handler);
    }

    this.getHandler = function () {
        if (handlers.length < 1) return null;
        var handler = handlers[0];
        handlers.splice(0, 1);
        return handler;
    }

    this.connect = function (url, doReconnect, onConnect, onError) {
        if (socket && socket.readyState != WebSocket.CLOSED) {
            if (socket.readyState == WebSocket.OPEN) {
                socket.onclose = function (e) { if (debug) console.log('WebSocket #' + socket.id + ' closed'); socket = null; WS.connect(url, doReconnect, onMessage, onError); };
                WS.disconnect();
                return true;
            }
            return false;
        }

        try { socket = new WebSocket(url); }
        catch (exception) { if (debug) console.log(exception); return false; }
        socket.id = id++;
        reconnect = doReconnect;

        socket.onmessage = function (e) {
            if (debug) console.log('WebSocket #' + socket.id + ' received: ' + e.data);
            var onMessage = WS.getHandler();
            if (onMessage) onMessage(e.data);
        }
        socket.onopen = function (e) {
            if (debug) console.log('WebSocket #' + socket.id + ' opened: ' + url);
            if (onConnect) onConnect();
        }
        socket.onclose = function (e) {
            if (debug) console.log('WebSocket #' + socket.id + ' closed');
            if (reconnect) setTimeout(function () { WS.connect(url, doReconnect, null, onError); }, 2000);
        }
        socket.onerror = function (e) {
            if (debug) console.log('WebSocket #' + socket.id + ' error: ' + e.data);
            if (onError) onError(e.data);
        }

        return true;
    }

    this.disconnect = function () {
        if (socket && (socket.readyState == WebSocket.OPEN || socket.readyState == WebSocket.CONNECTING)) {
            reconnect = false;
            socket.close();
            return true;
        }
        else return false;
    }

    this.send = function (data, handler) {
        if (!socket || socket.readyState != WebSocket.OPEN) return false;
        if (debug) console.log('WebSocket #' + socket.id + ' send: ' + data);
        WS.addHandler(handler);
        socket.send(data);
        return true;
    }

    return this;
} ();